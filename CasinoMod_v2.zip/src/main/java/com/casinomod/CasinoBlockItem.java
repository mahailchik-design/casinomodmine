package com.casinomod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

/** Блок казино: при установке строит целое казино перед игроком. */
public class CasinoBlockItem extends BlockItem {
    public CasinoBlockItem(Block block, Properties properties) {
        super(block, properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        if (player == null || !player.getAbilities().mayBuild) return InteractionResult.PASS;
        if (level.isClientSide()) return InteractionResult.SUCCESS;

        BlockPos pos = new BlockPlaceContext(ctx).getClickedPos();
        Direction forward = ctx.getHorizontalDirection();

        if (level.isOutsideBuildHeight(pos.getY() - 6) || level.isOutsideBuildHeight(pos.getY() + 15)) {
            return InteractionResult.FAIL;
        }
        if (level instanceof ServerLevel serverLevel) {
            CasinoBuilder.build(serverLevel, pos, forward);
            level.playSound(null, pos, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("gui.casinomod.built"), true);
        }
        ctx.getItemInHand().consume(1, player);
        return InteractionResult.SUCCESS;
    }
}
