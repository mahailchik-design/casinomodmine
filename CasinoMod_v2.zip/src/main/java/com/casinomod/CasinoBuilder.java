package com.casinomod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Строит казино 29 x 21 блок. Локальные координаты:
 * lx — вправо от входа (-14..14), lz — вглубь (0..20), ly — вверх (0 = уровень входа).
 */
public final class CasinoBuilder {
    private static final int HALF = 14;
    private static final int DEPTH = 20;
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_SUPPRESS_DROPS;

    // Буквы CASINO, 4x5
    private static final String[][] LETTERS = {
            {".XXX", "X...", "X...", "X...", ".XXX"},
            {".XX.", "X..X", "XXXX", "X..X", "X..X"},
            {".XXX", "X...", ".XX.", "...X", "XXX."},
            {"XXXX", ".XX.", ".XX.", ".XX.", "XXXX"},
            {"X..X", "XX.X", "XXXX", "X.XX", "X..X"},
            {".XX.", "X..X", "X..X", "X..X", ".XX."}
    };

    private final ServerLevel level;
    private final BlockPos origin;
    private final Direction fwd;
    private final Direction right;

    private CasinoBuilder(ServerLevel level, BlockPos origin, Direction fwd) {
        this.level = level;
        this.origin = origin;
        this.fwd = fwd;
        this.right = fwd.getClockWise();
    }

    public static void build(ServerLevel level, BlockPos origin, Direction forward) {
        new CasinoBuilder(level, origin, forward).run();
    }

    private BlockPos pos(int lx, int ly, int lz) {
        return new BlockPos(
                origin.getX() + fwd.getStepX() * lz + right.getStepX() * lx,
                origin.getY() + ly,
                origin.getZ() + fwd.getStepZ() * lz + right.getStepZ() * lx);
    }

    private void set(int lx, int ly, int lz, Block block) {
        level.setBlock(pos(lx, ly, lz), block.defaultBlockState(), FLAGS);
    }

    private void set(int lx, int ly, int lz, BlockState state) {
        level.setBlock(pos(lx, ly, lz), state, FLAGS);
    }

    private static boolean isPillar(int lx, int lz) {
        return (Math.abs(lx) == HALF && lz % 4 == 0)
                || ((lz == 0 || lz == DEPTH) && (lx + HALF) % 4 == 0);
    }

    private Block wallBlock(int lx, int ly, int lz) {
        boolean pillar = isPillar(lx, lz);
        boolean front = lz == 0;
        if (front && ly >= 5) return ly == 10 ? Blocks.GOLD_BLOCK : Blocks.RED_CONCRETE;
        if (ly == 10) return pillar ? Blocks.GOLD_BLOCK : Blocks.POLISHED_BLACKSTONE_BRICKS;
        if (pillar) return Blocks.GOLD_BLOCK;
        if (ly == 0) return Blocks.POLISHED_BLACKSTONE;
        if (!front && ly >= 2 && ly <= 6) return Blocks.RED_STAINED_GLASS;
        return Blocks.SMOOTH_QUARTZ;
    }

    private void machine(int lx, int lz, Direction facing) {
        set(lx, 0, lz, ModBlocks.SLOT_MACHINE.defaultBlockState()
                .setValue(HorizontalDirectionalBlock.FACING, facing));
    }

    private void run() {
        // 1. Очистка объёма, фундамент и пол
        for (int lx = -HALF; lx <= HALF; lx++) {
            for (int lz = 0; lz <= DEPTH; lz++) {
                for (int ly = 0; ly <= 14; ly++) set(lx, ly, lz, Blocks.AIR);
                for (int ly = -2; ly >= -6; ly--) {
                    BlockState s = level.getBlockState(pos(lx, ly, lz));
                    if (s.isAir() || s.canBeReplaced() || !s.getFluidState().isEmpty()) {
                        set(lx, ly, lz, Blocks.POLISHED_BLACKSTONE_BRICKS);
                    }
                }
                set(lx, -1, lz, ((lx + lz) & 1) == 0 ? Blocks.BLACK_CONCRETE : Blocks.RED_CONCRETE);
            }
        }

        // 2. Стены и потолок
        for (int lx = -HALF; lx <= HALF; lx++) {
            for (int lz = 0; lz <= DEPTH; lz++) {
                boolean edge = Math.abs(lx) == HALF || lz == 0 || lz == DEPTH;
                if (edge) {
                    for (int ly = 0; ly <= 10; ly++) set(lx, ly, lz, wallBlock(lx, ly, lz));
                } else {
                    boolean light = lx % 4 == 0 && Math.abs(lx) <= 12 && lz >= 2 && (lz - 2) % 4 == 0;
                    set(lx, 9, lz, light ? ModBlocks.CASINO_BLOCK : Blocks.POLISHED_BLACKSTONE_BRICKS);
                }
            }
        }

        // 3. Вывеска CASINO на фасаде
        for (int i = 0; i < LETTERS.length; i++) {
            int startX = -HALF + i * 5;
            for (int row = 0; row < 5; row++) {
                for (int col = 0; col < 4; col++) {
                    if (LETTERS[i][row].charAt(col) == 'X') set(startX + col, 9 - row, 0, Blocks.GOLD_BLOCK);
                }
            }
        }

        // 4. Вход
        for (int lx = -1; lx <= 1; lx++) {
            for (int ly = 0; ly <= 4; ly++) set(lx, ly, 0, Blocks.AIR);
        }

        // 5. Ковровая дорожка
        for (int lx = -1; lx <= 1; lx++) {
            for (int lz = 1; lz <= 17; lz++) set(lx, 0, lz, Blocks.RED_CARPET);
        }

        // 6. Игровые автоматы
        Direction left = right.getOpposite();
        for (int lz = 4; lz <= 16; lz += 2) {
            machine(-13, lz, right);
            machine(13, lz, left);
            machine(-7, lz, left);
            machine(-6, lz, right);
            machine(6, lz, left);
            machine(7, lz, right);
        }

        // 7. Пьедестал джекпота
        set(0, 0, 18, Blocks.GOLD_BLOCK);
        set(0, 1, 18, Blocks.DIAMOND_BLOCK);
        set(0, 2, 18, Blocks.EMERALD_BLOCK);
    }
}
