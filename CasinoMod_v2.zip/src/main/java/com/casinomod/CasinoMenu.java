package com.casinomod;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * Игровой автомат. Использует ванильный экран сундука 9x3 — отдельный клиентский код не нужен.
 * Ставка кладётся в слот BET, кнопка SPIN запускает барабаны.
 */
public class CasinoMenu extends AbstractContainerMenu {
    public static final int BET = 10;
    public static final int SPIN = 16;
    private static final int HINT = 19;
    private static final int INFO = 22;
    private static final int TITLE = 4;
    private static final int[] REELS = {12, 13, 14};

    private static final Item[] SYMBOLS = {Items.COAL, Items.REDSTONE, Items.IRON_INGOT,
            Items.GOLD_INGOT, Items.EMERALD, Items.DIAMOND, Items.NETHER_STAR};
    // Три одинаковых: уголь x2, железо x3, золото x5, изумруд x10, алмаз x25
    private static final Item[] TIER_ITEM = {Items.COAL, Items.IRON_INGOT, Items.GOLD_INGOT, Items.EMERALD, Items.DIAMOND};
    private static final int[] TIER_MULT = {2, 3, 5, 10, 25};
    private static final double[] TIER_CUM = {0.10, 0.15, 0.175, 0.19, 0.195};
    private static final double P_LOSE = 0.585;
    private static final double P_PAIR = 0.22; // пара — ставка возвращается

    private final SimpleContainer container = new SimpleContainer(27);
    private final ContainerLevelAccess access;
    private final Player player;

    private int spinTicks = -1;
    private ItemStack heldBet = ItemStack.EMPTY;
    private final Item[] result = new Item[3];
    private int multiplier;

    public CasinoMenu(int id, Inventory inv, ContainerLevelAccess access) {
        super(MenuType.GENERIC_9x3, id);
        this.access = access;
        this.player = inv.player;

        ItemStack pane = named(Items.BLACK_STAINED_GLASS_PANE, Component.literal(" "));
        for (int i = 0; i < 27; i++) container.setItem(i, pane.copy());
        container.setItem(BET, ItemStack.EMPTY);
        for (int r : REELS) {
            container.setItem(r, named(Items.GRAY_STAINED_GLASS_PANE, Component.literal("?").withStyle(ChatFormatting.GOLD)));
        }
        container.setItem(TITLE, named(Items.GOLD_BLOCK,
                Component.translatable("container.casinomod.slots").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)));
        container.setItem(SPIN, withLore(named(Items.EMERALD_BLOCK,
                        Component.translatable("gui.casinomod.spin").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)),
                Component.translatable("gui.casinomod.spin_hint")));
        container.setItem(HINT, named(Items.ARROW, Component.translatable("gui.casinomod.bet_hint").withStyle(ChatFormatting.YELLOW)));
        container.setItem(INFO, withLore(named(Items.BOOK,
                        Component.translatable("gui.casinomod.payouts").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD)),
                Component.translatable("gui.casinomod.pay_pair"),
                Component.translatable("gui.casinomod.pay_coal"),
                Component.translatable("gui.casinomod.pay_iron"),
                Component.translatable("gui.casinomod.pay_gold"),
                Component.translatable("gui.casinomod.pay_emerald"),
                Component.translatable("gui.casinomod.pay_diamond")));

        for (int i = 0; i < 27; i++) {
            final int idx = i;
            this.addSlot(new Slot(container, i, 8 + (i % 9) * 18, 18 + (i / 9) * 18) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return idx == BET && !isSpinning() && stack.getMaxStackSize() > 1;
                }

                @Override
                public boolean mayPickup(Player p) {
                    return idx == BET && !isSpinning();
                }
            });
        }
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                this.addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 84 + r * 18));
            }
        }
        for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(inv, c, 8 + c * 18, 142));
        }
    }

    private boolean isSpinning() {
        return spinTicks >= 0;
    }

    private static ItemStack named(Item item, Component name) {
        ItemStack s = new ItemStack(item);
        s.set(DataComponents.CUSTOM_NAME, name.copy().withStyle(st -> st.withItalic(false)));
        return s;
    }

    private static ItemStack withLore(ItemStack s, Component... lines) {
        List<Component> list = new java.util.ArrayList<>();
        for (Component c : lines) list.add(c.copy().withStyle(ChatFormatting.GRAY).withStyle(st -> st.withItalic(false)));
        s.set(DataComponents.LORE, new ItemLore(list));
        return s;
    }

    private void sound(SoundEvent ev, float pitch) {
        player.level().playSound(null, player.blockPosition(), ev, SoundSource.BLOCKS, 0.8F, pitch);
    }

    private void say(Component c) {
        player.displayClientMessage(c, true);
        player.displayClientMessage(c, false);
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player p) {
        if (slotId == SPIN) {
            if (clickType == ClickType.PICKUP || clickType == ClickType.QUICK_MOVE) startSpin();
            this.sendAllDataToRemote();
            return;
        }
        super.clicked(slotId, button, clickType, p);
    }

    private void startSpin() {
        if (isSpinning()) return;
        ItemStack bet = container.getItem(BET);
        if (bet.isEmpty()) {
            player.displayClientMessage(Component.translatable("gui.casinomod.no_bet").withStyle(ChatFormatting.RED), true);
            sound(SoundEvents.VILLAGER_NO, 1.0F);
            return;
        }
        heldBet = bet.copy();
        container.setItem(BET, ItemStack.EMPTY);
        roll(player.level().getRandom());
        spinTicks = 0;
        sound(SoundEvents.LEVER_CLICK, 1.0F);
    }

    private void roll(RandomSource rnd) {
        double d = rnd.nextDouble();
        if (d < P_LOSE) {
            int a = rnd.nextInt(SYMBOLS.length);
            int b;
            do { b = rnd.nextInt(SYMBOLS.length); } while (b == a);
            int c;
            do { c = rnd.nextInt(SYMBOLS.length); } while (c == a || c == b);
            result[0] = SYMBOLS[a];
            result[1] = SYMBOLS[b];
            result[2] = SYMBOLS[c];
            multiplier = 0;
        } else if (d < P_LOSE + P_PAIR) {
            int a = rnd.nextInt(SYMBOLS.length);
            int b;
            do { b = rnd.nextInt(SYMBOLS.length); } while (b == a);
            result[0] = result[1] = result[2] = SYMBOLS[a];
            result[rnd.nextInt(3)] = SYMBOLS[b];
            multiplier = 1;
        } else {
            double t = d - P_LOSE - P_PAIR;
            int tier = TIER_CUM.length - 1;
            for (int i = 0; i < TIER_CUM.length; i++) {
                if (t < TIER_CUM[i]) { tier = i; break; }
            }
            result[0] = result[1] = result[2] = TIER_ITEM[tier];
            multiplier = TIER_MULT[tier];
        }
    }

    /** Вызывается каждый серверный тик для игрока с открытым автоматом. */
    public void tick() {
        if (!isSpinning()) return;
        spinTicks++;
        RandomSource rnd = player.level().getRandom();
        for (int i = 0; i < 3; i++) {
            int stop = 20 + i * 12;
            if (spinTicks < stop) {
                if (spinTicks % 2 == 0) {
                    container.setItem(REELS[i], new ItemStack(SYMBOLS[rnd.nextInt(SYMBOLS.length)]));
                }
            } else if (spinTicks == stop) {
                container.setItem(REELS[i], new ItemStack(result[i]));
                sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F + i * 0.25F);
            }
        }
        if (spinTicks >= 20 + 2 * 12 + 12) finish();
    }

    private void finish() {
        spinTicks = -1;
        for (int i = 0; i < 3; i++) container.setItem(REELS[i], new ItemStack(result[i]));
        ItemStack bet = heldBet;
        heldBet = ItemStack.EMPTY;
        if (bet.isEmpty()) return;

        if (multiplier <= 0) {
            say(Component.translatable("gui.casinomod.lose").withStyle(ChatFormatting.RED));
            sound(SoundEvents.VILLAGER_NO, 0.8F);
            return;
        }
        int total = bet.getCount() * multiplier;
        giveOrDrop(player, bet.copyWithCount(total));
        if (multiplier == 1) {
            say(Component.translatable("gui.casinomod.push").withStyle(ChatFormatting.YELLOW));
        } else {
            say(Component.translatable("gui.casinomod.win", total, bet.getHoverName()).withStyle(ChatFormatting.GREEN));
            sound(SoundEvents.PLAYER_LEVELUP, 1.0F);
        }
    }

    private static void giveOrDrop(Player p, ItemStack stack) {
        while (!stack.isEmpty()) {
            ItemStack part = stack.split(stack.getMaxStackSize());
            p.getInventory().add(part);
            if (!part.isEmpty()) p.drop(part, false);
        }
    }

    @Override
    public ItemStack quickMoveStack(Player p, int index) {
        if (isSpinning()) return ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        if (index == BET) {
            if (!this.moveItemStackTo(stack, 27, 63, true)) return ItemStack.EMPTY;
        } else if (index >= 27) {
            if (!this.moveItemStackTo(stack, BET, BET + 1, false)) return ItemStack.EMPTY;
        } else {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
        return copy;
    }

    @Override
    public boolean stillValid(Player p) {
        return stillValid(this.access, p, ModBlocks.SLOT_MACHINE);
    }

    @Override
    public void removed(Player p) {
        super.removed(p);
        if (isSpinning()) finish();
        ItemStack bet = container.getItem(BET);
        if (!bet.isEmpty()) {
            container.setItem(BET, ItemStack.EMPTY);
            giveOrDrop(p, bet);
        }
    }
}
