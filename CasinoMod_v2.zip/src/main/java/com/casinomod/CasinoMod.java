package com.casinomod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;

public class CasinoMod implements ModInitializer {
    public static final String MOD_ID = "casinomod";
    private static final String GIFT_TAG = "casinomod_gift";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(entries -> {
            entries.accept(ModItems.CASINO_BLOCK);
            entries.accept(ModItems.SLOT_MACHINE);
        });

        // Блок казино выдаётся один раз при первом входе в мир
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();
            if (!player.getTags().contains(GIFT_TAG)) {
                player.addTag(GIFT_TAG);
                ItemStack gift = new ItemStack(ModItems.CASINO_BLOCK);
                player.getInventory().add(gift);
                if (!gift.isEmpty()) player.drop(gift, false);
            }
        });

        // Анимация автомата
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (p.containerMenu instanceof CasinoMenu menu) menu.tick();
            }
        });
    }
}
