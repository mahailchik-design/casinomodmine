package com.casinomod;

import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;

public final class ModItems {
    public static final Item CASINO_BLOCK = register("casino_block",
            p -> new CasinoBlockItem(ModBlocks.CASINO_BLOCK, p.useBlockDescriptionPrefix()));
    public static final Item SLOT_MACHINE = register("slot_machine",
            p -> new BlockItem(ModBlocks.SLOT_MACHINE, p.useBlockDescriptionPrefix()));

    private static Item register(String name, Function<Item.Properties, Item> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, CasinoMod.id(name));
        Item item = factory.apply(new Item.Properties().setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void init() {}
}
